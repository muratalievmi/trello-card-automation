import { useState, useEffect } from "react";
import MetamorphosisObject from "../components/MetamorphosisObject.jsx";
import { Narrator, LoadingQuill, Button } from "../components/UIComponents.jsx";
import { NARRATOR_TEXTS, COLORS } from "../constants.js";
import { ActionTypes } from "../reducer.js";
import { callAgent, parseAgentJSON } from "../api.js";
import { SIMULATOR_PROMPT } from "../prompts.js";

export default function Chapter4({ state, dispatch }) {
  const [selectedChoice, setSelectedChoice] = useState(null);
  const [showConsequence, setShowConsequence] = useState(false);

  // Generate scenarios on mount
  useEffect(() => {
    if (!state.simulatorData && !state.isLoading) {
      dispatch({ type: ActionTypes.SET_LOADING, payload: true });
      const context = [
        `Профиль искажений:\n${state.quizMd}`,
        `Проблема:\n${state.todoMd}`,
        `Исследование:\n${state.researchMd}`,
      ].join("\n\n");

      callAgent(SIMULATOR_PROMPT, context)
        .then((response) => {
          const data = parseAgentJSON(response);
          dispatch({ type: ActionTypes.SET_SIMULATOR, payload: data });
        })
        .catch((e) => dispatch({ type: ActionTypes.SET_ERROR, payload: "Ошибка симулятора: " + e.message }))
        .finally(() => dispatch({ type: ActionTypes.SET_LOADING, payload: false }));
    }
  }, []);

  const currentScenario = state.simulatorData?.scenarios?.[state.currentScenario];
  const allScenariosComplete = state.simulatorData && state.currentScenario >= (state.simulatorData.scenarios?.length || 0);

  const makeChoice = (index) => {
    if (showConsequence) return;
    setSelectedChoice(index);
    setShowConsequence(true);
    dispatch({ type: ActionTypes.MAKE_DECISION, payload: { scenario: state.currentScenario, choice: index } });
  };

  const nextScenario = () => {
    dispatch({ type: ActionTypes.NEXT_SCENARIO });
    setSelectedChoice(null);
    setShowConsequence(false);
  };

  const isLastScenario = state.currentScenario >= (state.simulatorData?.scenarios?.length || 0) - 1;

  return (
    <div>
      <MetamorphosisObject
        stage={allScenariosComplete && state.showFinalWisdom ? 4 : 3}
        size={allScenariosComplete && state.showFinalWisdom ? 180 : 130}
      />
      <Narrator text={NARRATOR_TEXTS[4]} />

      {state.isLoading && <LoadingQuill />}

      {state.simulatorData?.arena_intro && !allScenariosComplete && (
        <p className="egg-status" style={{ color: COLORS.accent }}>
          ⚔️ {state.simulatorData.arena_intro}
        </p>
      )}

      {/* Active scenario */}
      {currentScenario && !allScenariosComplete && (
        <div className="scenario-card">
          <span className="scenario-counter">
            Сценарий {state.currentScenario + 1}/{state.simulatorData.scenarios.length}
          </span>
          <h3 className="scenario-title">⚔️ {currentScenario.title}</h3>
          <p className="scenario-setup">{currentScenario.setup}</p>

          {currentScenario.choices.map((choice, i) => {
            const isSelected = selectedChoice === i;
            let className = "scenario-choice";
            if (showConsequence && isSelected) {
              className += choice.bias_triggered ? " biased" : " rational";
            }

            return (
              <div key={i} style={{ marginBottom: 7 }}>
                <button
                  onClick={() => makeChoice(i)}
                  className={className}
                  style={{ fontWeight: isSelected ? 700 : 400 }}
                >
                  {choice.text}
                </button>

                {showConsequence && isSelected && (
                  <div className="consequence-box">
                    <p className="consequence-text">
                      <strong>Последствия:</strong> {choice.consequence}
                    </p>
                    {choice.bias_triggered && (
                      <p className="consequence-bias">
                        ⚠️ Искажение: <strong>{choice.bias_triggered}</strong>
                      </p>
                    )}
                    <p className="consequence-wisdom">💡 {choice.wisdom}</p>
                  </div>
                )}
              </div>
            );
          })}

          {showConsequence && (
            <div style={{ textAlign: "right", marginTop: 12 }}>
              <Button onClick={nextScenario}>
                {isLastScenario ? "Разбить скорлупу →" : "Следующий сценарий →"}
              </Button>
            </div>
          )}
        </div>
      )}

      {/* Hatch button */}
      {allScenariosComplete && !state.showFinalWisdom && (
        <div className="stage-complete">
          <Button onClick={() => dispatch({ type: ActionTypes.SHOW_FINAL })} variant="gold">
            🔥 Разбить яйцо!
          </Button>
        </div>
      )}

      {/* Final Wisdom Scroll */}
      {state.showFinalWisdom && (
        <div className="final-wisdom">
          {state.simulatorData.creature_name && (
            <h2 className="creature-name">{state.simulatorData.creature_name}</h2>
          )}
          <p className="hatching-message">{state.simulatorData.hatching_message}</p>

          <div className="journey-summary">
            <p className="journey-title">Твой путь метаморфозы:</p>
            <p>🌫️→🥚 Из хаоса собрал яйцо за {state.interviewMessages.filter((m) => m.role === "user").length} ответов</p>
            <p>📚 Впитал {state.researchData?.insights?.length || 0} знаний — яйцо окрасилось</p>
            <p>🪞 Прошёл {state.quizAnswers.length} испытаний — трещины засветились</p>
            <p>⚔️ Принял {state.decisions.length} решений — скорлупа разбита!</p>
          </div>
        </div>
      )}
    </div>
  );
}
