import { useEffect } from "react";
import MetamorphosisObject from "../components/MetamorphosisObject.jsx";
import { Narrator, LoadingQuill, InsightCard, Button } from "../components/UIComponents.jsx";
import { NARRATOR_TEXTS, COLORS } from "../constants.js";
import { ActionTypes } from "../reducer.js";
import { callAgent, parseAgentJSON } from "../api.js";
import { RESEARCH_PROMPT } from "../prompts.js";

export default function Chapter2({ state, dispatch }) {
  useEffect(() => {
    if (!state.researchData && !state.isLoading) {
      dispatch({ type: ActionTypes.SET_LOADING, payload: true });
      callAgent(RESEARCH_PROMPT, `Проблема пользователя:\n${state.todoMd}`)
        .then((response) => {
          const data = parseAgentJSON(response);
          dispatch({ type: ActionTypes.SET_RESEARCH, payload: data });
        })
        .catch((e) => dispatch({ type: ActionTypes.SET_ERROR, payload: "Ошибка исследования: " + e.message }))
        .finally(() => dispatch({ type: ActionTypes.SET_LOADING, payload: false }));
    }
  }, []);

  return (
    <div>
      <MetamorphosisObject stage={2} size={130} />
      <Narrator text={NARRATOR_TEXTS[2]} />

      {state.isLoading && <LoadingQuill />}

      {state.researchData && (
        <>
          {state.researchData.egg_description && (
            <p className="egg-status" style={{ color: COLORS.blue }}>
              🥚 {state.researchData.egg_description}
            </p>
          )}

          <div className="research-narrative">
            📖 {state.researchData.narrative}
          </div>

          {state.researchData.insights?.map((insight, i) => (
            <InsightCard key={i} insight={insight} delay={i * 350} />
          ))}

          <div className="stage-complete">
            <Button
              onClick={() => dispatch({ type: ActionTypes.SHOW_TRANSITION, payload: "research.md" })}
              variant="green"
            >
              🪞 К Зеркалу Разума →
            </Button>
          </div>
        </>
      )}
    </div>
  );
}
