import { useState, useEffect } from "react";
import MetamorphosisObject from "../components/MetamorphosisObject.jsx";
import { Narrator, Button } from "../components/UIComponents.jsx";
import { CHAPTERS, NARRATOR_TEXTS } from "../constants.js";
import { ActionTypes } from "../reducer.js";

export default function Intro({ dispatch }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    setTimeout(() => setVisible(true), 300);
  }, []);

  return (
    <div className="intro-screen" style={{ opacity: visible ? 1 : 0 }}>
      <h1 className="app-title">MINDFORGE</h1>
      <p className="app-subtitle">Фабрика трансформации знания в опыт</p>

      <MetamorphosisObject stage={0} size={150} />
      <Narrator text={NARRATOR_TEXTS[0]} />

      <div className="intro-card">
        <p className="intro-text">
          Ты отправишься через <strong>4 главы</strong>. В каждой — хаос над головой
          будет превращаться во что-то конкретное. К финалу из яйца родится нечто живое.
        </p>
        {CHAPTERS.map((ch) => (
          <div key={ch.id} className="chapter-preview">
            <span style={{ fontSize: 16 }}>{ch.icon}</span>
            <span>
              <strong>Гл. {ch.id}:</strong> {ch.title} — <em>{ch.subtitle}</em>
            </span>
          </div>
        ))}
      </div>

      <Button onClick={() => dispatch({ type: ActionTypes.SET_CHAPTER, payload: 1 })}>
        Начать путешествие →
      </Button>
    </div>
  );
}
