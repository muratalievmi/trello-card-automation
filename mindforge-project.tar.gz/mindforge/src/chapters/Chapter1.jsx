import { useState, useCallback, useEffect, useRef } from "react";
import MetamorphosisObject from "../components/MetamorphosisObject.jsx";
import { Narrator, SpeechBubble, LoadingQuill, Button } from "../components/UIComponents.jsx";
import { NARRATOR_TEXTS } from "../constants.js";
import { ActionTypes } from "../reducer.js";
import { callAgent } from "../api.js";
import { INTERVIEW_PROMPT } from "../prompts.js";

export default function Chapter1({ state, dispatch }) {
  const [input, setInput] = useState("");
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [state.interviewMessages]);

  // Start interview on mount
  useEffect(() => {
    if (state.interviewMessages.length === 0 && !state.isLoading) {
      dispatch({ type: ActionTypes.SET_LOADING, payload: true });
      callAgent(INTERVIEW_PROMPT, "Начни интервью. Задай первый вопрос.")
        .then((response) => {
          dispatch({ type: ActionTypes.ADD_MESSAGE, payload: { role: "assistant", content: response } });
          dispatch({ type: ActionTypes.SET_INTERVIEW_STEP, payload: 1 });
        })
        .catch((e) => dispatch({ type: ActionTypes.SET_ERROR, payload: e.message }))
        .finally(() => dispatch({ type: ActionTypes.SET_LOADING, payload: false }));
    }
  }, []);

  const sendMessage = useCallback(async () => {
    if (!input.trim() || state.isLoading) return;
    const userMsg = input.trim();
    setInput("");

    dispatch({ type: ActionTypes.ADD_MESSAGE, payload: { role: "user", content: userMsg } });
    dispatch({ type: ActionTypes.SET_LOADING, payload: true });

    try {
      const history = [
        ...state.interviewMessages.map((m) => ({ role: m.role, content: m.content })),
        { role: "user", content: userMsg },
      ];

      const response = await callAgent(INTERVIEW_PROMPT, history);
      dispatch({ type: ActionTypes.ADD_MESSAGE, payload: { role: "assistant", content: response } });
      dispatch({ type: ActionTypes.SET_INTERVIEW_STEP, payload: state.interviewStep + 1 });

      // Check if interview is complete
      if (response.includes("КОРЕНЬ:") || state.interviewStep >= 5) {
        const todoContent = [
          "# Цель",
          "",
          response,
          "",
          "## Контекст диалога",
          ...history.filter((m) => m.role === "user").map((m) => `- ${m.content}`),
        ].join("\n");
        dispatch({ type: ActionTypes.SET_TODO, payload: todoContent });
      }
    } catch (e) {
      dispatch({ type: ActionTypes.SET_ERROR, payload: e.message });
    }

    dispatch({ type: ActionTypes.SET_LOADING, payload: false });
  }, [input, state, dispatch]);

  return (
    <div>
      <MetamorphosisObject stage={state.todoMd ? 1 : 0} size={130} />
      <Narrator text={NARRATOR_TEXTS[1]} />

      <div className="chat-container">
        {state.interviewMessages.map((msg, i) => (
          <SpeechBubble
            key={i}
            text={msg.content}
            isUser={msg.role === "user"}
            isLast={i === state.interviewMessages.length - 1}
          />
        ))}
        {state.isLoading && <LoadingQuill />}
        <div ref={messagesEndRef} />
      </div>

      {!state.todoMd ? (
        <div className="input-row">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            placeholder="Твой ответ..."
            disabled={state.isLoading}
            className="chat-input"
          />
          <Button onClick={sendMessage} disabled={state.isLoading || !input.trim()}>
            Ответить
          </Button>
        </div>
      ) : (
        <div className="stage-complete">
          <div className="complete-banner">
            <p>✅ Яйцо собрано! Хаос стал зерном. Свиток todo.md готов.</p>
          </div>
          <Button
            onClick={() => dispatch({ type: ActionTypes.SHOW_TRANSITION, payload: "todo.md" })}
            variant="green"
          >
            📜 Передать в Библиотеку →
          </Button>
        </div>
      )}
    </div>
  );
}
