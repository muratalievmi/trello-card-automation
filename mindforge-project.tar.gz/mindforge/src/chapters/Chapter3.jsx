import { useState, useEffect } from "react";
import MetamorphosisObject from "../components/MetamorphosisObject.jsx";
import { Narrator, LoadingQuill, Button } from "../components/UIComponents.jsx";
import { NARRATOR_TEXTS, COLORS } from "../constants.js";
import { ActionTypes } from "../reducer.js";
import { callAgent, parseAgentJSON } from "../api.js";
import { QUIZ_PROMPT } from "../prompts.js";

export default function Chapter3({ state, dispatch }) {
  const [selectedOption, setSelectedOption] = useState(null);
  const [showExplanation, setShowExplanation] = useState(false);

  // Generate quiz on mount
  useEffect(() => {
    if (!state.quizData && !state.isLoading) {
      dispatch({ type: ActionTypes.SET_LOADING, payload: true });
      callAgent(QUIZ_PROMPT, `Исследование:\n${state.researchMd}\n\nПроблема:\n${state.todoMd}`)
        .then((response) => {
          const data = parseAgentJSON(response);
          dispatch({ type: ActionTypes.SET_QUIZ, payload: data });
        })
        .catch((e) => dispatch({ type: ActionTypes.SET_ERROR, payload: "Ошибка квиза: " + e.message }))
        .finally(() => dispatch({ type: ActionTypes.SET_LOADING, payload: false }));
    }
  }, []);

  const currentQuestion = state.quizData?.questions?.[state.currentQuizIndex];
  const isQuizComplete = state.quizData && state.currentQuizIndex >= (state.quizData.questions?.length || 0);

  const selectOption = (index) => {
    if (showExplanation) return;
    setSelectedOption(index);
    setShowExplanation(true);
  };

  const nextQuestion = () => {
    const option = currentQuestion.options[selectedOption];
    dispatch({
      type: ActionTypes.ANSWER_QUIZ,
      payload: {
        q: state.currentQuizIndex,
        option: selectedOption,
        biased: option.biased,
        bias: currentQuestion.bias,
      },
    });
    setSelectedOption(null);
    setShowExplanation(false);
  };

  // Generate profile when quiz is done
  useEffect(() => {
    if (isQuizComplete && !state.quizMd) {
      const biasedAnswers = state.quizAnswers.filter((a) => a.biased);
      const biasNames = biasedAnswers.map((a) => a.bias);
      const profile = [
        `Профиль: ${biasedAnswers.length}/${state.quizAnswers.length} под искажениями`,
        biasNames.join(", "),
      ].join("\n");
      dispatch({
        type: ActionTypes.SET_QUIZ_PROFILE,
        payload: profile,
        biases: biasNames,
      });
    }
  }, [isQuizComplete, state.quizMd, state.quizAnswers, dispatch]);

  return (
    <div>
      <MetamorphosisObject stage={3} size={130} />
      <Narrator text={NARRATOR_TEXTS[3]} />

      {state.isLoading && <LoadingQuill />}

      {state.quizData?.mirror_message && !isQuizComplete && (
        <p className="egg-status" style={{ color: COLORS.gold }}>
          🪞 {state.quizData.mirror_message}
        </p>
      )}

      {/* Active question */}
      {currentQuestion && !isQuizComplete && (
        <div className="quiz-card">
          <div className="quiz-header">
            <span className="quiz-counter">
              Испытание {state.currentQuizIndex + 1}/{state.quizData.questions.length}
            </span>
            <span className="quiz-bias">🎯 {currentQuestion.bias}</span>
          </div>

          <p className="quiz-scenario">{currentQuestion.scenario}</p>

          {currentQuestion.options.map((opt, i) => {
            const isSelected = showExplanation && i === selectedOption;
            let className = "quiz-option";
            if (isSelected) className += opt.biased ? " biased" : " rational";
            return (
              <div key={i} style={{ marginBottom: 6 }}>
                <button onClick={() => selectOption(i)} className={className}>
                  {opt.text}
                </button>
                {isSelected && (
                  <p className={`quiz-explanation ${opt.biased ? "biased" : "rational"}`}>
                    {opt.biased ? "⚠️" : "✅"} {opt.explanation}
                  </p>
                )}
              </div>
            );
          })}

          {showExplanation && (
            <div style={{ textAlign: "right", marginTop: 12 }}>
              <Button onClick={nextQuestion}>Далее →</Button>
            </div>
          )}
        </div>
      )}

      {/* Quiz results */}
      {isQuizComplete && state.quizMd && (
        <div className="stage-complete">
          <div className="quiz-results">
            <h3>🪞 Отражение</h3>
            <p className="quiz-score">
              {state.quizAnswers.filter((a) => a.biased).length} / {state.quizAnswers.length}
            </p>
            <p className="quiz-score-label">решений под влиянием искажений</p>
            {state.biasProfile.length > 0 && (
              <div className="bias-tags">
                {state.biasProfile.map((b, i) => (
                  <span key={i} className="bias-tag">{b}</span>
                ))}
              </div>
            )}
          </div>
          <Button
            onClick={() => dispatch({ type: ActionTypes.SHOW_TRANSITION, payload: "quiz.md" })}
            variant="green"
          >
            ⚔️ На Арену →
          </Button>
        </div>
      )}
    </div>
  );
}
