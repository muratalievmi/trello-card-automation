// ═══════════════════════════════════════════════════
// Application state management via useReducer
// ═══════════════════════════════════════════════════

export const initialState = {
  // Navigation
  currentChapter: 0, // 0 = intro, 1-4 = chapters

  // Chapter 1: Interview
  interviewMessages: [], // [{role: "user"|"assistant", content: string}]
  interviewStep: 0,
  todoMd: null, // Generated todo.md content

  // Chapter 2: Research
  researchData: null, // Parsed JSON from research agent
  researchMd: null, // Stringified for next agent

  // Chapter 3: Quiz
  quizData: null, // Parsed JSON from quiz agent
  quizAnswers: [], // [{q, option, biased, bias}]
  currentQuizIndex: 0,
  quizMd: null, // Generated profile
  biasProfile: [], // Array of bias names user is vulnerable to

  // Chapter 4: Simulator
  simulatorData: null, // Parsed JSON from simulator agent
  currentScenario: 0,
  decisions: [], // [{scenario, choice}]

  // UI state
  isTransitioning: false,
  transitionFile: "",
  isLoading: false,
  error: null,
  showFinalWisdom: false,
};

export const ActionTypes = {
  SET_CHAPTER: "SET_CHAPTER",
  ADD_MESSAGE: "ADD_MESSAGE",
  SET_INTERVIEW_STEP: "SET_INTERVIEW_STEP",
  SET_TODO: "SET_TODO",
  SET_RESEARCH: "SET_RESEARCH",
  SET_QUIZ: "SET_QUIZ",
  ANSWER_QUIZ: "ANSWER_QUIZ",
  SET_QUIZ_PROFILE: "SET_QUIZ_PROFILE",
  SET_SIMULATOR: "SET_SIMULATOR",
  MAKE_DECISION: "MAKE_DECISION",
  NEXT_SCENARIO: "NEXT_SCENARIO",
  SHOW_TRANSITION: "SHOW_TRANSITION",
  SET_LOADING: "SET_LOADING",
  SET_ERROR: "SET_ERROR",
  SHOW_FINAL: "SHOW_FINAL",
};

export function appReducer(state, action) {
  switch (action.type) {
    case ActionTypes.SET_CHAPTER:
      return { ...state, currentChapter: action.payload, isTransitioning: false };

    case ActionTypes.ADD_MESSAGE:
      return {
        ...state,
        interviewMessages: [...state.interviewMessages, action.payload],
      };

    case ActionTypes.SET_INTERVIEW_STEP:
      return { ...state, interviewStep: action.payload };

    case ActionTypes.SET_TODO:
      return { ...state, todoMd: action.payload };

    case ActionTypes.SET_RESEARCH:
      return {
        ...state,
        researchData: action.payload,
        researchMd: JSON.stringify(action.payload),
      };

    case ActionTypes.SET_QUIZ:
      return { ...state, quizData: action.payload };

    case ActionTypes.ANSWER_QUIZ:
      return {
        ...state,
        quizAnswers: [...state.quizAnswers, action.payload],
        currentQuizIndex: state.currentQuizIndex + 1,
      };

    case ActionTypes.SET_QUIZ_PROFILE:
      return {
        ...state,
        quizMd: action.payload,
        biasProfile: action.biases || [],
      };

    case ActionTypes.SET_SIMULATOR:
      return { ...state, simulatorData: action.payload };

    case ActionTypes.MAKE_DECISION:
      return {
        ...state,
        decisions: [...state.decisions, action.payload],
      };

    case ActionTypes.NEXT_SCENARIO:
      return { ...state, currentScenario: state.currentScenario + 1 };

    case ActionTypes.SHOW_TRANSITION:
      return {
        ...state,
        isTransitioning: true,
        transitionFile: action.payload,
      };

    case ActionTypes.SET_LOADING:
      return { ...state, isLoading: action.payload };

    case ActionTypes.SET_ERROR:
      return { ...state, error: action.payload };

    case ActionTypes.SHOW_FINAL:
      return { ...state, showFinalWisdom: true };

    default:
      return state;
  }
}
