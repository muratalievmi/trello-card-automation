// ═══════════════════════════════════════════════════
// Anthropic API communication layer
// ═══════════════════════════════════════════════════

const API_URL = "https://api.anthropic.com/v1/messages";
const MODEL = "claude-sonnet-4-20250514";
const MAX_TOKENS = 1000;

/**
 * Call Claude with a system prompt and user message(s).
 * @param {string} systemPrompt - The agent's system prompt
 * @param {string|Array} messages - Single string or array of {role, content} objects
 * @returns {Promise<string>} The assistant's text response
 */
export async function callAgent(systemPrompt, messages) {
  const formattedMessages = Array.isArray(messages)
    ? messages
    : [{ role: "user", content: messages }];

  const response = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: MAX_TOKENS,
      system: systemPrompt,
      messages: formattedMessages,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`API error ${response.status}: ${error}`);
  }

  const data = await response.json();
  return data.content?.map((block) => block.text || "").join("") || "";
}

/**
 * Parse JSON from AI response, handling markdown code fences.
 * @param {string} text - Raw AI response text
 * @returns {Object} Parsed JSON object
 */
export function parseAgentJSON(text) {
  // Strip markdown code fences if present
  let clean = text.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();

  try {
    return JSON.parse(clean);
  } catch {
    // Fallback: extract first JSON object from text
    const match = text.match(/\{[\s\S]*\}/);
    if (match) {
      return JSON.parse(match[0]);
    }
    throw new Error("Failed to parse AI response as JSON");
  }
}
