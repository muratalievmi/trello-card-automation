import { useState, useEffect } from "react";
import { COLORS, CHAPTERS } from "../constants.js";

// ─── Narrator Box ────────────────────────────────
export function Narrator({ text }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    setTimeout(() => setVisible(true), 200);
  }, []);

  return (
    <div
      className="narrator-box"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(12px)",
      }}
    >
      <span className="narrator-icon">📜</span>
      {text}
    </div>
  );
}

// ─── Speech Bubble ───────────────────────────────
export function SpeechBubble({ text, isUser, isLast }) {
  const [visible, setVisible] = useState(!isLast);
  useEffect(() => {
    if (isLast) setTimeout(() => setVisible(true), 150);
  }, [isLast]);

  return (
    <div
      style={{
        display: "flex",
        justifyContent: isUser ? "flex-end" : "flex-start",
        marginBottom: 10,
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(8px)",
        transition: "all 0.4s",
      }}
    >
      <div
        className={isUser ? "bubble-user" : "bubble-agent"}
        style={{
          borderRadius: isUser ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
        }}
      >
        {!isUser && <span className="agent-label">🔦 Исследователь</span>}
        {text}
      </div>
    </div>
  );
}

// ─── Loading Quill ───────────────────────────────
export function LoadingQuill() {
  return (
    <div className="loading-quill">
      <div className="quill-icon">✒️</div>
      <p>Перо скрипит по пергаменту...</p>
    </div>
  );
}

// ─── Button ──────────────────────────────────────
export function Button({ onClick, children, variant = "primary", disabled }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`btn btn-${variant}`}
      style={{ opacity: disabled ? 0.5 : 1, cursor: disabled ? "not-allowed" : "pointer" }}
    >
      {children}
    </button>
  );
}

// ─── File Transition Overlay ─────────────────────
export function FileTransition({ fileName, onComplete }) {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 100);
    const t2 = setTimeout(() => setPhase(2), 1200);
    const t3 = setTimeout(() => setPhase(3), 2200);
    const t4 = setTimeout(() => onComplete?.(), 3000);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
    };
  }, [onComplete]);

  return (
    <div className="file-transition-overlay">
      <div
        style={{
          transform: phase >= 1 ? "scale(1)" : "scale(0.3)",
          opacity: phase >= 1 ? 1 : 0,
          transition: "all 0.8s ease",
        }}
      >
        <div
          className="file-scroll"
          style={{
            transform: phase >= 2 ? "translateY(-16px)" : "translateY(0)",
          }}
        >
          <span style={{ fontSize: 30 }}>📄</span>
          <span className="file-name">{fileName}</span>
        </div>
      </div>
      <p
        className="file-transition-text"
        style={{ opacity: phase >= 2 ? 1 : 0 }}
      >
        {phase >= 3 ? "Свиток передан →" : "Формируется свиток знания..."}
      </p>
    </div>
  );
}

// ─── Insight Card ────────────────────────────────
export function InsightCard({ insight, delay }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setVisible(true), delay);
    return () => clearTimeout(t);
  }, [delay]);

  return (
    <div
      className="insight-card"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateX(0)" : "translateX(-16px)",
      }}
    >
      <div className="insight-header">
        <span style={{ fontSize: 22 }}>{insight.icon}</span>
        <h4>{insight.bias}</h4>
      </div>
      <p className="insight-desc">{insight.description}</p>
      <p className="insight-example">
        <strong>Пример:</strong> {insight.example}
      </p>
      <p className="insight-antidote">
        <strong>Противоядие:</strong> {insight.antidote}
      </p>
    </div>
  );
}

// ─── Chapter Navigation ──────────────────────────
export function ChapterNav({ currentChapter }) {
  return (
    <div className="chapter-nav">
      {CHAPTERS.map((ch) => {
        const isActive = ch.id === currentChapter;
        const isPast = ch.id < currentChapter;
        const isFuture = ch.id > currentChapter;
        return (
          <div
            key={ch.id}
            className={`chapter-tab ${isActive ? "active" : ""} ${isPast ? "past" : ""}`}
            style={{ opacity: isFuture ? 0.35 : 1 }}
          >
            <span style={{ fontSize: 13 }}>{isPast ? "✅" : ch.icon}</span>
            <span className="chapter-tab-title">{ch.title}</span>
          </div>
        );
      })}
    </div>
  );
}
