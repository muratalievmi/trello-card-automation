import { useMemo } from "react";

/**
 * Central metamorphosis visual — an SVG object that transforms through 5 stages:
 * 0: Chaos cloud (floating symbols)
 * 1: Plain warm egg (seed of idea)
 * 2: Blue knowledge egg (with vein patterns)
 * 3: Glowing cracking egg (orange, with light leaking through cracks)
 * 4: Hatched creature (phoenix/dragon with wings)
 */
export default function MetamorphosisObject({ stage, size = 180 }) {
  const s = size;
  const cx = s / 2;
  const cy = s / 2;

  const chaosParticles = useMemo(
    () =>
      Array.from({ length: 12 }, (_, i) => ({
        x: cx + (Math.random() - 0.5) * s * 0.7,
        y: cy + (Math.random() - 0.5) * s * 0.6,
        r: 3 + Math.random() * 8,
        delay: i * 0.3,
        char: ["?", "!", "...", "→", "←", "~", "△", "○", "□", "◇", "∞", "≈"][i],
      })),
    [cx, cy, s]
  );

  return (
    <div style={{ display: "flex", justifyContent: "center", margin: "16px 0" }}>
      <svg width={s} height={s + 20} viewBox={`0 0 ${s} ${s + 20}`} style={{ overflow: "visible" }}>
        <defs>
          <radialGradient id="eg1" cx="40%" cy="35%">
            <stop offset="0%" stopColor="#fef3d0" />
            <stop offset="100%" stopColor="#e8c97a" />
          </radialGradient>
          <radialGradient id="eg2" cx="40%" cy="35%">
            <stop offset="0%" stopColor="#c8e6ff" />
            <stop offset="50%" stopColor="#7eb8e0" />
            <stop offset="100%" stopColor="#4a8ebb" />
          </radialGradient>
          <radialGradient id="eg3" cx="40%" cy="35%">
            <stop offset="0%" stopColor="#ffe4a0" />
            <stop offset="40%" stopColor="#ffb347" />
            <stop offset="100%" stopColor="#ff6b35" />
          </radialGradient>
          <radialGradient id="egGlow" cx="50%" cy="50%">
            <stop offset="0%" stopColor="rgba(255,200,50,0.6)" />
            <stop offset="100%" stopColor="rgba(255,200,50,0)" />
          </radialGradient>
          <filter id="ds">
            <feDropShadow dx="2" dy="4" stdDeviation="4" floodColor="#2a1810" floodOpacity="0.25" />
          </filter>
          <filter id="gf">
            <feGaussianBlur stdDeviation="6" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Stage 0: Chaos Cloud */}
        {stage === 0 && (
          <g>
            <ellipse cx={cx} cy={cy} rx={s * 0.38} ry={s * 0.32} fill="none" stroke="#8b7355" strokeWidth="2" strokeDasharray="6 4" opacity="0.5">
              <animate attributeName="rx" values={`${s * 0.36};${s * 0.4};${s * 0.36}`} dur="3s" repeatCount="indefinite" />
              <animate attributeName="ry" values={`${s * 0.3};${s * 0.34};${s * 0.3}`} dur="2.5s" repeatCount="indefinite" />
            </ellipse>
            {chaosParticles.map((p, i) => (
              <text key={i} x={p.x} y={p.y} fontSize={p.r + 4} fill="#8b7355" textAnchor="middle" opacity="0.6" fontFamily="Georgia">
                {p.char}
                <animate attributeName="x" values={`${p.x};${p.x + (Math.random() - 0.5) * 20};${p.x}`} dur={`${2 + p.delay * 0.5}s`} repeatCount="indefinite" />
                <animate attributeName="y" values={`${p.y};${p.y + (Math.random() - 0.5) * 15};${p.y}`} dur={`${2.5 + p.delay * 0.3}s`} repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.3;0.7;0.3" dur={`${1.5 + p.delay * 0.2}s`} repeatCount="indefinite" />
              </text>
            ))}
            <text x={cx} y={s + 16} textAnchor="middle" fontSize="11" fill="#8b7355" fontFamily="Georgia" fontStyle="italic">
              хаос идей
            </text>
          </g>
        )}

        {/* Stage 1: Warm Egg */}
        {stage === 1 && (
          <g filter="url(#ds)">
            <ellipse cx={cx} cy={cy + 5} rx={s * 0.22} ry={s * 0.3} fill="url(#eg1)" stroke="#c4a35a" strokeWidth="2">
              <animate attributeName="ry" values={`${s * 0.28};${s * 0.3};${s * 0.28}`} dur="4s" repeatCount="indefinite" />
            </ellipse>
            <ellipse cx={cx - s * 0.06} cy={cy - s * 0.05} rx={s * 0.08} ry={s * 0.12} fill="white" opacity="0.25" />
            <text x={cx} y={s + 16} textAnchor="middle" fontSize="11" fill="#8b7355" fontFamily="Georgia" fontStyle="italic">
              зерно идеи
            </text>
          </g>
        )}

        {/* Stage 2: Knowledge Egg */}
        {stage === 2 && (
          <g filter="url(#ds)">
            <ellipse cx={cx} cy={cy + 5} rx={s * 0.24} ry={s * 0.33} fill="url(#eg2)" stroke="#3a6b8f" strokeWidth="2">
              <animate attributeName="ry" values={`${s * 0.31};${s * 0.33};${s * 0.31}`} dur="4s" repeatCount="indefinite" />
            </ellipse>
            {[0, 60, 120, 180, 240, 300].map((angle, i) => {
              const rad = (angle * Math.PI) / 180;
              return (
                <line key={i} x1={cx + Math.cos(rad) * s * 0.08} y1={cy + 5 + Math.sin(rad) * s * 0.12} x2={cx + Math.cos(rad) * s * 0.2} y2={cy + 5 + Math.sin(rad) * s * 0.28} stroke="#a0d4f0" strokeWidth="1.5" opacity="0.5" strokeLinecap="round">
                  <animate attributeName="opacity" values="0.3;0.6;0.3" dur={`${2 + i * 0.3}s`} repeatCount="indefinite" />
                </line>
              );
            })}
            <ellipse cx={cx - s * 0.07} cy={cy - s * 0.06} rx={s * 0.07} ry={s * 0.11} fill="white" opacity="0.3" />
            <text x={cx} y={s + 16} textAnchor="middle" fontSize="11" fill="#3a6b8f" fontFamily="Georgia" fontStyle="italic">
              знание растёт
            </text>
          </g>
        )}

        {/* Stage 3: Glowing Cracking Egg */}
        {stage === 3 && (
          <g>
            <ellipse cx={cx} cy={cy + 5} rx={s * 0.35} ry={s * 0.42} fill="url(#egGlow)">
              <animate attributeName="rx" values={`${s * 0.33};${s * 0.37};${s * 0.33}`} dur="2s" repeatCount="indefinite" />
              <animate attributeName="ry" values={`${s * 0.4};${s * 0.44};${s * 0.4}`} dur="2s" repeatCount="indefinite" />
            </ellipse>
            <g filter="url(#ds)">
              <ellipse cx={cx} cy={cy + 5} rx={s * 0.26} ry={s * 0.35} fill="url(#eg3)" stroke="#cc5500" strokeWidth="2" />
            </g>
            <polyline points={`${cx - 5},${cy - s * 0.15} ${cx - 12},${cy - s * 0.05} ${cx - 3},${cy + s * 0.02} ${cx - 14},${cy + s * 0.12}`} fill="none" stroke="#ffeebb" strokeWidth="2.5" strokeLinecap="round" opacity="0.9">
              <animate attributeName="opacity" values="0.6;1;0.6" dur="1.5s" repeatCount="indefinite" />
            </polyline>
            <polyline points={`${cx + 8},${cy - s * 0.1} ${cx + 15},${cy} ${cx + 6},${cy + s * 0.08}`} fill="none" stroke="#ffeebb" strokeWidth="2" strokeLinecap="round" opacity="0.8">
              <animate attributeName="opacity" values="0.5;0.9;0.5" dur="1.8s" repeatCount="indefinite" />
            </polyline>
            {[0, 72, 144, 216, 288].map((angle, i) => {
              const rad = (angle * Math.PI) / 180;
              return (
                <circle key={i} cx={cx + Math.cos(rad) * s * 0.3} cy={cy + 5 + Math.sin(rad) * s * 0.38} r="2.5" fill="#ffcc33" opacity="0.7">
                  <animate attributeName="r" values="1.5;3.5;1.5" dur={`${1.2 + i * 0.2}s`} repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.4;0.9;0.4" dur={`${1.5 + i * 0.3}s`} repeatCount="indefinite" />
                </circle>
              );
            })}
            <text x={cx} y={s + 16} textAnchor="middle" fontSize="11" fill="#cc5500" fontFamily="Georgia" fontStyle="italic">
              готово к рождению
            </text>
          </g>
        )}

        {/* Stage 4: Hatched Creature */}
        {stage === 4 && (
          <g>
            <ellipse cx={cx - 15} cy={cy + s * 0.25} rx="12" ry="8" fill="#e8c97a" stroke="#c4a35a" strokeWidth="1" opacity="0.7" transform={`rotate(-20,${cx - 15},${cy + s * 0.25})`} />
            <ellipse cx={cx + 18} cy={cy + s * 0.28} rx="10" ry="7" fill="#e8c97a" stroke="#c4a35a" strokeWidth="1" opacity="0.6" transform={`rotate(15,${cx + 18},${cy + s * 0.28})`} />
            <g filter="url(#gf)">
              <ellipse cx={cx} cy={cy + 5} rx={s * 0.14} ry={s * 0.18} fill="#ff7b4a" stroke="#cc4400" strokeWidth="1.5" />
              <path d={`M${cx - s * 0.12},${cy} Q${cx - s * 0.35},${cy - s * 0.25} ${cx - s * 0.08},${cy - s * 0.15}`} fill="none" stroke="#ffaa44" strokeWidth="3" strokeLinecap="round" opacity="0.9">
                <animate attributeName="d" values={`M${cx - s * 0.12},${cy} Q${cx - s * 0.35},${cy - s * 0.25} ${cx - s * 0.08},${cy - s * 0.15};M${cx - s * 0.12},${cy} Q${cx - s * 0.38},${cy - s * 0.3} ${cx - s * 0.08},${cy - s * 0.18};M${cx - s * 0.12},${cy} Q${cx - s * 0.35},${cy - s * 0.25} ${cx - s * 0.08},${cy - s * 0.15}`} dur="3s" repeatCount="indefinite" />
              </path>
              <path d={`M${cx + s * 0.12},${cy} Q${cx + s * 0.35},${cy - s * 0.25} ${cx + s * 0.08},${cy - s * 0.15}`} fill="none" stroke="#ffaa44" strokeWidth="3" strokeLinecap="round" opacity="0.9">
                <animate attributeName="d" values={`M${cx + s * 0.12},${cy} Q${cx + s * 0.35},${cy - s * 0.25} ${cx + s * 0.08},${cy - s * 0.15};M${cx + s * 0.12},${cy} Q${cx + s * 0.38},${cy - s * 0.3} ${cx + s * 0.08},${cy - s * 0.18};M${cx + s * 0.12},${cy} Q${cx + s * 0.35},${cy - s * 0.25} ${cx + s * 0.08},${cy - s * 0.15}`} dur="3s" repeatCount="indefinite" />
              </path>
              <circle cx={cx - 8} cy={cy - 5} r="3.5" fill="#fff8e0" />
              <circle cx={cx + 8} cy={cy - 5} r="3.5" fill="#fff8e0" />
              <circle cx={cx - 7} cy={cy - 5} r="2" fill="#2a1810" />
              <circle cx={cx + 9} cy={cy - 5} r="2" fill="#2a1810" />
              {[-12, -4, 4, 12].map((dx, i) => (
                <ellipse key={i} cx={cx + dx} cy={cy - s * 0.17 - i * 2} rx="4" ry={8 + i * 2} fill={i % 2 === 0 ? "#ff6633" : "#ffcc33"} opacity="0.8">
                  <animate attributeName="ry" values={`${8 + i * 2};${12 + i * 2};${8 + i * 2}`} dur={`${0.8 + i * 0.2}s`} repeatCount="indefinite" />
                </ellipse>
              ))}
            </g>
            {Array.from({ length: 8 }, (_, i) => {
              const angle = (i * 45 * Math.PI) / 180;
              const dist = s * 0.35 + Math.random() * s * 0.1;
              return (
                <text key={i} x={cx + Math.cos(angle) * dist} y={cy + Math.sin(angle) * dist} fontSize="10" fill="#ffcc33" textAnchor="middle" opacity="0.7">
                  ✦
                  <animate attributeName="opacity" values="0.3;0.9;0.3" dur={`${1 + i * 0.3}s`} repeatCount="indefinite" />
                </text>
              );
            })}
            <text x={cx} y={s + 16} textAnchor="middle" fontSize="11" fill="#cc4400" fontFamily="Georgia" fontStyle="italic" fontWeight="bold">
              рождён!
            </text>
          </g>
        )}
      </svg>
    </div>
  );
}
