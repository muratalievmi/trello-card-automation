import { useReducer, useCallback } from "react";
import { appReducer, initialState, ActionTypes } from "./reducer.js";
import { ChapterNav, FileTransition } from "./components/UIComponents.jsx";
import Intro from "./chapters/Intro.jsx";
import Chapter1 from "./chapters/Chapter1.jsx";
import Chapter2 from "./chapters/Chapter2.jsx";
import Chapter3 from "./chapters/Chapter3.jsx";
import Chapter4 from "./chapters/Chapter4.jsx";

export default function App() {
  const [state, dispatch] = useReducer(appReducer, initialState);

  const handleTransitionComplete = useCallback(() => {
    dispatch({ type: ActionTypes.SET_CHAPTER, payload: state.currentChapter + 1 });
  }, [state.currentChapter]);

  const renderChapter = () => {
    switch (state.currentChapter) {
      case 0:
        return <Intro dispatch={dispatch} />;
      case 1:
        return <Chapter1 state={state} dispatch={dispatch} />;
      case 2:
        return <Chapter2 state={state} dispatch={dispatch} />;
      case 3:
        return <Chapter3 state={state} dispatch={dispatch} />;
      case 4:
        return <Chapter4 state={state} dispatch={dispatch} />;
      default:
        return null;
    }
  };

  return (
    <div className="app-root">
      {/* Chapter navigation */}
      {state.currentChapter > 0 && <ChapterNav currentChapter={state.currentChapter} />}

      {/* Main content */}
      <div className="app-content">{renderChapter()}</div>

      {/* File transition overlay */}
      {state.isTransitioning && (
        <FileTransition fileName={state.transitionFile} onComplete={handleTransitionComplete} />
      )}

      {/* Error toast */}
      {state.error && !state.isLoading && (
        <div className="error-toast">
          <p>{state.error}</p>
          <button onClick={() => dispatch({ type: ActionTypes.SET_ERROR, payload: null })}>
            Закрыть
          </button>
        </div>
      )}
    </div>
  );
}
